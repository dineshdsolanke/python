from django import forms
from .models import loanModel

class LoanForm(forms.ModelForm):
    class Meta:
        model = loanModel
        fields = "__all__"