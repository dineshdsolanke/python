from django.db import models

# Create your models here.
class loanModel(models.Model):
    loanid= models.IntegerField(primary_key=True)
    custmer_name = models.CharField(max_length=35)
    custmer_emails= models.EmailField()
    income = models.FloatField()
    dateofdiss = models.DateField()
    