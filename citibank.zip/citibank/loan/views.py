from django.shortcuts import render,redirect
from .forms import LoanForm
from .models import loanModel
# Create your views here.

def insert_view(request):
    form = LoanForm()
    if request.method=='POST':
        form= LoanForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/showloans/")

    return render(request,'loan/loanrequestform.html',{'form':form})


def read_view(request):
    objlist= loanModel.objects.all()
    return render(request,'loan/loanshow.html',{'objlist':objlist})


def delete_view(request,loanid):
    customerobj = loanModel.objects.get(loanid=loanid)
    customerobj.delete()
    return redirect("/showloans/")